using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour {

    public float speed;
    public float acceleration;
    [SerializeField]

    //Enemy object
    public GameObject enemy;
    //number of seconds past
    private float secondsPast;
    bool zDown;
    bool isDashing;
    bool wasDashing;
    float canDashTimer;
    bool canDash;
    float dashTimer;
    //List of enemies
    public List<GameObject> enemies;
    float timeLvl = 2;
    int counter = 0;

    // Start is called before the first frame update
    void Start()
    {
        //adding enemies to a list of enemies
        enemies = new List<GameObject>();
        //GameObject newEnemy = Instantiate(enemy);
        //newEnemy.GetComponent<Enemy>().Init(this.gameObject);
        //enemies.Add(newEnemy);
        canDashTimer = 0.0f;
        speed = 0.3f;
        if(acceleration<0.002) acceleration = 0.002f;
        secondsPast = 2.0f;
    }

    // Update is called once per frame
    void Update() {
        if(canDashTimer<=0.0f)
        {
            canDash = true;
        }
        zDown = Input.GetKey(KeyCode.Z);
        if (zDown && wasDashing == false && canDash)
            isDashing = true;

        canDashTimer-=Time.deltaTime;

        if(isDashing)
        {
            speed += 0.75f;
            wasDashing = true;
            dashTimer = 0.0f;
            isDashing = false;
            canDashTimer = 3.0f;
            canDash = false;
        }

        if(wasDashing)
        {
            dashTimer += Time.deltaTime;
        }

        if(wasDashing && dashTimer>=0.2)
        {
            wasDashing = false;
            speed -= 0.75f;
        }
        //updating time and speed
        secondsPast += Time.deltaTime;
        speed += (acceleration * Time.deltaTime);

        if (secondsPast > timeLvl) //spawn a new cube
        {
            var rand = Random.Range(0, 2);
            secondsPast = 0;
            //basic change for time level, we cut this out for whatever
            if (timeLvl -(Time.deltaTime * 2) > 0.5)
            {
                timeLvl -= Time.deltaTime * 2;
            }

            //in the air
            if (rand == 1)
            { //adding to list
                GameObject enemyObject = Instantiate(enemy, new Vector3(0, .12f, 1f), Quaternion.identity);
                enemyObject.GetComponent<Enemy>().Init(this.gameObject);
                enemies.Add(enemyObject);
            }
            else //on the ground
            {
                GameObject enemyObject = (Instantiate(enemy, new Vector3(0, .03f, 1f), Quaternion.identity));
                enemyObject.GetComponent<Enemy>().Init(this.gameObject);
                enemies.Add(enemyObject);
            }
        }
    }

    //changes speed value of specific enemy
    void ChangeEnemySpeed(float s, GameObject e)
    {
        var script = e.GetComponent<Enemy>();
        var sp = script.speed = s;
        e.GetComponent<Enemy>().speed = sp;
    }
}
