using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using v3 = UnityEngine.Vector3;
public class PlayerMovement : MonoBehaviour
{
    Animator animator;
    Mesh meshToCollide;
    GameObject mainCam;

    
    private Rigidbody rBody;
    private Collider col;

    //motion states 
    enum motion
    {
        running,
        jumping, 
        sliding,
        diving,
        none
    }
    motion playerstate;
    bool running;
    //key presses
    bool W, A, S, D, R, LshiftDown, Lshift, LshiftUp, middleMouse, spaceDown, space, spaceUp, Lctrl;
    bool isgrounded;
    private bool InMyState;

    //animation states
    int runningHash;
    int jumpHash;
    int slideHash;
    int diveHash;
    int velocityHash;

    public float velocity = 0.0f;
    private float inputBuffer = 0.0f;
    //movements
    float vel_Run;
    float acc_Run;
    
    public bool ObsticleCollision;
    //floats for animation transition
    private float clipDuration;
    private float dTime;
    private float distToGround;
    GameObject collidedObj;
    public GameObject manager;
    EnemyManager enemyManger;
    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        rBody = GetComponent<Rigidbody>();
        col = GetComponent<Collider>();

        runningHash = Animator.StringToHash("isRunning");
        jumpHash = Animator.StringToHash("Jump");
        slideHash = Animator.StringToHash("Slide");
        velocityHash = Animator.StringToHash("Velocity");
        diveHash = Animator.StringToHash("Dive");
        running = animator.GetBool(runningHash);
        distToGround = col.bounds.extents.y;

        //Running at game start
        running = true;
        GetComponent<CapsuleCollider>().enabled = false;
        playerstate = motion.running;
        isgrounded = true;
        enemyManger = manager.GetComponent<EnemyManager>();
    } 

    // Update is called once per frame
    void Update()
    {
        //Keyboard inputs being initialized
        W = Input.GetKey(KeyCode.W);
        A = Input.GetKey(KeyCode.A);
        D = Input.GetKey(KeyCode.D);
        S = Input.GetKey(KeyCode.S);
        R = Input.GetKeyDown(KeyCode.R);
        LshiftDown = Input.GetKeyDown(KeyCode.LeftShift);
        LshiftUp = Input.GetKeyUp(KeyCode.LeftShift);
        Lshift = Input.GetKey(KeyCode.LeftShift);
        spaceDown = Input.GetKeyDown(KeyCode.Space);
        spaceUp = Input.GetKeyUp(KeyCode.Space);
        space = Input.GetKey(KeyCode.Space);
        Lctrl = Input.GetKey(KeyCode.LeftControl);
        middleMouse = Input.GetMouseButton(2);

        CheckGameOver();
    }

    void LateUpdate()
    {
        bool canInput = (inputBuffer == 0 && playerstate == motion.running); //> animator.GetCurrentAnimatorStateInfo(0).length
        if (S && canInput && !W && !D)
        {
            playerstate = motion.sliding;
        }
        if (W && canInput && !S && !D)
        {
            playerstate = motion.jumping;
        }
        if (D && canInput && !W && !S)
        {
            playerstate = motion.diving;
        }
        animator.speed = 0.8f + enemyManger.speed/4;
        Debug.Log(animator.speed);
        //rBody.mass 
        switch (playerstate)
        {
            case motion.running:
                inputBuffer = 0;
                rBody.mass = animator.speed;
                if (GetComponent<MeshCollider>().enabled == false)
                {
                    MeshToggle(false);
                }
                RunMotion();
                break;
            case motion.jumping:
                rBody.mass = 1;
                if (GetComponent<MeshCollider>().enabled == false)
                {
                    MeshToggle(false);
                }
                if (canInput)
                {
                    
                    JumpMotion();
                }
                else if (inputBuffer >= animator.GetCurrentAnimatorStateInfo(0).length)
                {
                    inputBuffer = 0;
                    playerstate = motion.running;
                }
                inputBuffer += Time.deltaTime;
                break;
            case motion.sliding:
                animator.speed = 1 + enemyManger.speed / 4;
                if (canInput)
                {
                    SlideMotion();
                }
                else if (inputBuffer >= animator.GetCurrentAnimatorStateInfo(0).length)
                {    
                    inputBuffer = 0;
                    playerstate = motion.running;
                    MeshToggle(false);
                }
                inputBuffer += Time.deltaTime;
                break;
            case motion.diving:
                animator.speed = 1 + enemyManger.speed / 4;
                if (canInput)
                {
                    DiveMotion();
                }
                else if (inputBuffer >= animator.GetCurrentAnimatorStateInfo(0).length)
                {
                    inputBuffer = 0;
                    playerstate = motion.running;
                    MeshToggle(false);
                }
                inputBuffer += Time.deltaTime;
                break;
            case motion.none:
                break;
            default:
                break;
        }
    }

    //Function for handling the slide motion
    private void DiveMotion()
    {
        if (gameObject.transform.position.y > 0.01 || isgrounded == false)
        {
            return;
        }
        animator.SetTrigger(diveHash);
        MeshToggle(true);
    }

    //Function for handling the slide motion
    private void SlideMotion()
    {
        if (gameObject.transform.position.y > 0.01 || isgrounded == false)
        {
            return;
        }
        animator.SetTrigger(slideHash);
        MeshToggle(true);
    }

    //Function for handling the jump motion
    private void JumpMotion()
    { 
        //exit jump if needed based on height
        if (isgrounded == false || isPlaying(animator, 0, "Jump"))
        {
            MeshToggle(false);
            return;
        }
        else if(isPlaying(animator, 0, "Jump") == false && isgrounded)
        {
            var mass = 1; //GetComponent<Rigidbody>().mass 
            //Debug.Log(mass);
            rBody.AddForce(Vector3.up * mass * 2.2f, ForceMode.Impulse);
            animator.SetTrigger(jumpHash);
            //rBody.AddForce(Vector3.up * 2.2f, ForceMode.Impulse);
        }
    }

    void MeshToggle(bool check)
    {
        Physics.IgnoreCollision(GetComponent<MeshCollider>(), GetComponent<CapsuleCollider>());
        if (check)
        {
            GetComponent<MeshCollider>().enabled = false;
            GetComponent<CapsuleCollider>().enabled = true;
        }
        else
        {
            
            GetComponent<MeshCollider>().enabled = true;
            GetComponent<CapsuleCollider>().enabled = false;
        }
    }

    void OnCollisionEnter(Collision theCollision)
    {
        var obj = theCollision.gameObject;
        if (obj.tag == "floor")
        {
            isgrounded = true;
        }
        if (obj.tag == "obsticle" && gameObject.transform.position.y < 0.02 && 
            (gameObject.transform.position.z < obj.transform.position.z) && ObsticleCollision)
        {
            Destroy(theCollision.gameObject);
            if(playerstate != motion.sliding)
            {
                rBody.AddForce(Vector3.back, ForceMode.Impulse);
            }
            
        }
    }
    void OnCollisionExit(Collision theCollision)
    {
        if (theCollision.gameObject.tag == "floor")
        {
            isgrounded = false;
        }
    }

    private bool IsGrounded()
    {
        
        return !Physics.Raycast(transform.position, -Vector3.up, GetComponent<MeshCollider>().bounds.extents.y);
    }
    
    //Function for handling the run motion
    private void RunMotion()
    {
        
        if (R)
        {
            running = true; 
        }
        if (animator.GetCurrentAnimatorStateInfo(0).IsName("Running"))
        {
            //switching to main state 
            playerstate = motion.running;
            
        }
        animator.SetBool(runningHash, running);
    }

    //Returns a boolean depending on if there is an animation playing
    bool isPlaying(Animator anim, int layer, string stateName)
    {
        if (anim.GetCurrentAnimatorStateInfo(layer).IsName(stateName) &&
                anim.GetCurrentAnimatorStateInfo(layer).normalizedTime < 1.0f)
            return true;
        else
            return false;
    }
    //more precise check for animation duration
    bool FinishedAnimation(string name)
    {
        var clipname = animator.GetCurrentAnimatorClipInfo(0)[0].clip.name;
        if(clipname == name)
        {
           
            var animDuration = animator.GetCurrentAnimatorStateInfo(0).length;
            var elapsedTime = animator.GetCurrentAnimatorStateInfo(0).normalizedTime;
            //var bEnd = (elapsedTime == animDuration / 2f);
            var dur = animDuration / 2f;
            var bEnd = (elapsedTime == dur - 1);
            var bFinished = (elapsedTime > dur);

            //Debug.Log(clipname);
            AnimatorClipInfo[] animations = animator.GetCurrentAnimatorClipInfo(0);
            if (bFinished)
            {
               
                return true;
            }
        }

        return false;
    }

    private void CheckGameOver() {
        //  If the player is off-screen, load game over scene
        Renderer rend = gameObject.GetComponentInChildren<Renderer>();
        if(!rend.isVisible && Time.timeSinceLevelLoad > 2 || gameObject.transform.position.z <-0.6) {
            Loader.Load(Loader.Scene.GameOver);
        }
    }
}
