﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Scene_Loader : MonoBehaviour 
{
    public void LoadGame() 
    {
        Loader.Load(Loader.Scene.Animations);
    }

    public void LoadMain() 
    {
        Loader.Load(Loader.Scene.Main_Menu);
    }
}
