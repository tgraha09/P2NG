using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

    //enemy speed, position, and timer for spawning purposes
    public float speed = 0f;
    float originalZ = 0;
    Vector3 position;
    public GameObject manager;
    // Start is called before the first frame update
    void Start() {
        position = gameObject.transform.position;
        originalZ = position.z;
    }

    // Update is called once per frame
    void Update() {
        speed = manager.GetComponent<EnemyManager>().speed;
        position.z -= speed * Time.deltaTime;

        //updates position
        if(position.z < -1)
        {
            //destroying gameobject if we're past the a certain point 
            Destroy(gameObject);
        }

        gameObject.transform.position = position;
    }

    //function to change the speed, make enemies go faster (presumably)
    public void ChangeSpeed(float newSpeed) {
        speed = newSpeed;
    }

    public void Init(GameObject manager)
    {
        this.manager = manager;
    }
}
