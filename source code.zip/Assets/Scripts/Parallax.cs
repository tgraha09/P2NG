﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallax : MonoBehaviour
{

    public GameObject p1;
    public GameObject p2;
    Vector3 pos1;
    Vector3 pos2;
    public float speed1 = 0.05f;
    private float zspeed1 = 0;
    public float speed2 = 0.05f;
    private float zspeed2 = 0;
    float diff;
    Vector3 original;
    // Start is called before the first frame update
    void Start()
    {
        zspeed1 = p1.transform.position.z;
        zspeed2 = p2.transform.position.z;
        diff = Math.Abs(zspeed1 - zspeed2);
        
    }

    void FixedUpdate()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        pos1 = p1.transform.position;
        pos2 = p2.transform.position;
        zspeed1 -=speed1*Time.deltaTime/5;
        zspeed2 -= speed2 * Time.deltaTime/5;
        //Debug.Log(diff);
        if (zspeed1 < -12)
        {
            //Debug.Log(zspeed1);
            zspeed1 += diff*2;
        }
        if (zspeed2 < -12)
        {
            //Debug.Log(zspeed1);
            zspeed2 += diff*2;
        }
        pos1.z = zspeed1;
        p1.transform.position = pos1;
        pos2.z = zspeed2;
        p2.transform.position = pos2;
    }
}
